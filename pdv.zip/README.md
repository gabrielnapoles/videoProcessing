# videoProcessing
Repository to store some tests concerning videoProcessing subjects and tools.
